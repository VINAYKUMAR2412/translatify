<?php
// Header with nav, dark mode toggle
