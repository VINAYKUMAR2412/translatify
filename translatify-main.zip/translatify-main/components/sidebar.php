<div class="sidebar">
    <h2>Translatify</h2>
    <ul>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="translate.php">Translate</a></li>
        <li><a href="history.php">History</a></li>
        <li><a href="pay.php">Upgrade</a></li>
        <li><a href="settings.php">Settings</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
