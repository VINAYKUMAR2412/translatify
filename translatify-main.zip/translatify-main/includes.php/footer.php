<!-- Footer -->
<footer class="mt-20 text-center text-sm text-gray-500 pb-6">
  <div class="max-w-7xl mx-auto px-6">
    <p>© <?= date('Y') ?> Translatify. Built with ❤️ for multilingual communication.</p>
  </div>
</footer>

</body>
</html>
