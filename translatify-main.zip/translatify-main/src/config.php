<?php
return [
    "api_key" => "AIzaSyDe_lWzivEo6E7d_7X7v4iTrwlHH_2ln4c",  // Replace with your actual API key
];
?>
